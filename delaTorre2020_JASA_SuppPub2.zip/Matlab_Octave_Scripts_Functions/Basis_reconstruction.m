%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function Vr = Basis_reconstruction(V,fs,t_rec)     (revised Nov-2019)
% This function provides a transformation Vr providing the reconstruction
% of a function x(t) evaluated at times t_rec after a projection with a
% transformation providing a representation in the reduced space V:
%  * Vr*(V*x) provides V'*(V*x) evaluated at times given by t_rec  
%  * It is equivalent to:   interp1(t,V'*(V*x),t_rec) (but more efficient)
% Example
%    x          original function at t=(0:(J-1))/fs
%    V = Basis_LogScale(J,K_dec);   provides the transformation V 
%    V*x;       representation at reduced space
%    V'*(V*x);  projection into original representation space
%    Vr*(V*x);  reconstruction of projection for time instants t_rec
%    semilogx(t,x,t,V'*(V*x),t_rec,Vr*(V*x),t_rec,interp1(t,V'*(V*x),t_rec))
% Syntax:
%    Vr = Basis_reconstruction(V,fs,t_rec)
% Input parameters:
%    V: basis of functions providing representation in reduced space
%    fs: sampling frequency of original representation
%    t_rec: time values in which the function is being reconstructed
% Output parameters:
%    Vr: transformation providing reconstruction at t_rec from reduced
%    representation
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama (2019)
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Vr = Basis_reconstruction(V,fs,t_rec)
[K,J]=size(V);
t=(0:(J-1))/fs;
Vr=zeros(length(t_rec),K);
for k=1:K
    Vr(:,k)=interp1(t,V(k,:),t_rec,'linear',0)';
end
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
