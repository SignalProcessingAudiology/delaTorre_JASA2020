%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% script_LatDepFiltering_1response.m (simplified version just for 1 response)
% This script provides a demonstration of the latency-dependent filtering
% * Some AEP responses (from EEGs recorded at different ISI) are loaded
% * The orthonormalized latency-dependent filtering and down-sampling
%     matrix V_r is generated for the selected resolution Kdec (Jr x J matrix)
% * The compact representation is estimated: x_r = V_r * x  (Jr samples)
% * The filtered signal is estimated for each sample in the original
%     representation: x_lp = V_r' * x_r  (J samples)
% * The matrix providing reconstruction at at specific latency values is
%     also generated: V_rec (Jrec x Jr matrix)
% * The filtered signal, reconstructed at the specific latency values, is
%     estimated: x_rec = V_rec * x_r  (Jrec samples)
% * The different responses are represented in figures 1, 2, 3, 4
%    not filtered:            x (J samples)    -> figure 1 
%    compact representation:  x_r (Jr samples) -> figure 2
%    filtered at standard representation: x_lp (J samples) -> figure 3
%    filtered at specific latency values: x_rec (J_rec smaples) -> figure 4 
% * The rows of the matrix (i.e. the orthonormal functions of the basis)
% are also represented in figures 5 (for linearly scaled latency axis) and
% 6 (logarithmically scaled latency axis).
%
% This script requires the functions: 
%     * Basis_LinLog_RRC.m
%     * Basis_reconstruction.m
% This script also requires the data file (containing 18 AEP responses):
%     * data_subject_1.mat
% The script is configured by selecting appropriate resolution in the
% latency dependent filtering (Kdec) and reconstruction resolution
% (Rec_res). "Kdec" should be in the range 5 to 200; "Rec_res" should be
% greater than Kdec (recommended Rec_res=2*Kdec at least).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; clc; warning('off','all');

Kdec=25;                 % number of samples/decade in the latency-dependent filtering
Rec_res=200;             % reconstruction resolution in samples/decade
Selected_resp=1;         % response to be selected (between 1 and 18)

load data_subject_1.mat  % Loading the responses: AEP_resp (18 AEP responses); tms (time in ms)
x=AEP_resp(:,Selected_resp); % Only one response selected
J=length(tms);           % number of samples in the response
Fs=1000/(tms(2)-tms(1)); % sampling rate

Vr=Basis_LinLog_RRC(J,Kdec);  % orthonormalized matrix for lat-dep-filt and down-sampling
Jr=length(Vr(:,1));      % number of samples in the compact representation
xr=Vr*x;                 % compact representation of the lat-dep filtered responses
xlp=Vr'*xr;              % lat-dep filtered responses at standard representation
tr0ms=0.6; tr1ms=1000;   % limits of the latency interval for reconstruction, in ms
trms=tr0ms*10.^(0:1/Rec_res:log10(tr1ms/tr0ms))'; % specific latency values for reconstruction (in ms)
tr=trms/1000;            % specific latency values for reconstrution (in s)
Vrec=Basis_reconstruction(Vr,Fs,tr); % matrix providing reconstruction at tr
Jrec=length(Vrec(:,1));  % number of reconstructed samples
xrec=Vrec*xr;            % lat-dep filtered responses reconstructed at tr

% NOT FILTERED RESPONSES
figure(1); clf; 
semilogx(tms,x,'-r');
xlim([1 1000]); grid on
title(sprintf('Not filtered:   x  (%d samp.)',J));
xlabel('Latency (ms)'); ylabel('Amplitude')

% FILTERED RESPONSES: COMPACT REPRESENTATION
figure(2); clf;
plot(xr,'.-r');
xlim([1 Jr]); grid on
title(sprintf('Lat-dep filtered (%.1f samp./dec.):   x_r=V_r�x  (compact repres, %d samp.)',Kdec,Jr));
xlabel('Sample index in the compact representation'); ylabel('Amplitude')

% FILTERED RESPONSES: RECONSTRUCTED AT ORIGINAL REPRESENTATION
figure(3); clf;
semilogx(tms,xlp,'-r');
xlim([1 1000]); grid on
title(sprintf('Lat-dep filtered (%.1f samp./dec.):   x_{lp}=V_r^T�x_r  (%d samp.)',Kdec,J));
xlabel('Latency (ms)'); ylabel('Amplitude')

% FILTERED RESPONSES: RECONSTRUCTED AT SPECIFIC LATENCY VALUES tr 
figure(4); clf;
semilogx(trms,xrec,'-r');
xlim([1 1000]); grid on
title(sprintf('Lat-dep filtered (%.1f samp./dec.):   x_{rec}=V_{rec}�x_r  (%d samp.)',Kdec,Jrec));
xlabel('Latency (ms)'); ylabel('Amplitude')

% ORTHONORMALIZED MATRIX PROVIDING LAT-DEP-FILTERING
figure(5); clf;
h0=Vr(round(Jr/2),:);
y0=min(h0)-0.6*(max(h0)-min(h0)); y1=max(h0)+0.6*(max(h0)-min(h0)); 
plot(tms,Vr','r',tms,h0,'.-k')
xlim([0 1000]); ylim([y0 y1]); grid on;
xlabel('Latency (ms)'); ylabel('Amplitude')
title('Rows of the filtering matrix (functions of the basis)')
% ORTHONORMALIZED MATRIX PROVIDING LAT-DEP-FILTERING (Log-scaled latency axis) 
figure(6); clf;
semilogx(tms,Vr','r',tms,h0,'.-k')
xlim([1 1000]); ylim([y0 y1]); grid on;
xlabel('Latency (ms)'); ylabel('Amplitude')
title('Rows of the filtering matrix (functions of the basis)')

return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%